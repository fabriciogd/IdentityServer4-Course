﻿namespace SkyCommerce.Models
{
    public enum TipoEndereco
    {
        Entrega = 1,
        CartaoCredito = 2
    }
}