﻿namespace SkyCommerce.Data.Entities
{
    internal class Categoria
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string NomeUnico { get; set; }
        public string Descricao { get; set; }
        public string Imagem { get; set; }
        public string ImagemCapa { get; set; }

    }
}
