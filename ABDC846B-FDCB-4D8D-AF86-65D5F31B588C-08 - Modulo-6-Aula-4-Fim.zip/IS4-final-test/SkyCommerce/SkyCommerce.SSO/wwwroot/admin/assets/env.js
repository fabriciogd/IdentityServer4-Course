var ENV = {
    ApiUrl: 'http://localhost:5000',
    UiUrl: 'http://localhost:5000',
    AuthorityUrl: 'http://localhost:5000',   
    AddUserPassword: true,
    CommunityEdition: true,
    UserManagementDisabled: false
};
